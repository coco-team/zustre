int real_to_int (double in1) { return (int)in1; }

double int_to_real (int in1) { return (double)in1; }
